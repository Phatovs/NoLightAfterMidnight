// NoLightAfterMidnight - HUD: saat, gün, benzin, kamera adı, tamir barı, mesajlar
#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "NLTypes.h"
#include "NLHUDWidget.generated.h"

class UTextBlock;
class UProgressBar;
class UWidget;

/**
 * Tüm mantık C++'ta. Editörde bu sınıftan türeyen bir Widget Blueprint (WBP_NLHUD) yapın
 * ve aşağıdaki isimlerle widget'lar koyun. Hepsi opsiyonel: koymadığınız alan atlanır.
 */
UCLASS()
class NOLIGHTAFTERMIDNIGHT_API UNLHUDWidget : public UUserWidget
{
	GENERATED_BODY()

protected:
	virtual void NativeConstruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

	// --- Her zaman ---
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UTextBlock> DayText;            // "GECE 1"
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UTextBlock> ClockText;          // "02:14 AM"
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UTextBlock> InteractPromptText; // "[E] Masaya otur"
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UProgressBar> FlashlightBar;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UTextBlock> FuelCanText;        // "Benzin bidonu taşıyorsun"

	// --- Masada (kamera arayüzü) ---
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UWidget> CameraPanel;           // elektrik varken görünür
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UWidget> NoPowerPanel;          // elektrik yokken ("UI kapanmış hali")
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UTextBlock> CameraNameText;     // "Cam03"
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UProgressBar> FuelBar;          // benzin seviyesi
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UProgressBar> FlashCooldownBar; // 2 sn cooldown
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UTextBlock> GeneratorStatusText;// "JENERATÖR ARIZALI!"

	// --- Tamir mini oyunu ---
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UWidget> RepairPanel;
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UProgressBar> RepairProgressBar; // "TAMİR EDİLİYOR..."
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UWidget> RepairZone;   // yeşil bölge (sol kenara hizalı Image)
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UWidget> RepairNeedle; // ibre (sol kenara hizalı Image)

	// --- Ekran ortası mesajları ---
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UTextBlock> CenterMessageText; // "DAY 2", "GAME OVER"
	UPROPERTY(meta = (BindWidgetOptional)) TObjectPtr<UWidget> GameOverPanel;

	// Tamir barının piksel genişliği (RepairZone/Needle konumlandırması için)
	UPROPERTY(EditAnywhere, Category = "NL|HUD") float RepairTrackWidth = 400.f;
	// Oyun içi saat: 00:00'dan 06:00'ya
	UPROPERTY(EditAnywhere, Category = "NL|HUD") int32 NightStartHour = 0;
	UPROPERTY(EditAnywhere, Category = "NL|HUD") int32 NightEndHour = 6;
	UPROPERTY(EditAnywhere, Category = "NL|HUD") float CenterMessageDuration = 4.f;

	UFUNCTION() void HandleDayStarted(int32 Day);
	UFUNCTION() void HandleDayEnded(int32 Day);
	UFUNCTION() void HandleGameOverScreen(ENLGameOverReason Reason);
	UFUNCTION() void HandleGameWon();

private:
	float CenterMessageTimer = 0.f;
	bool bPersistentMessage = false;

	void ShowCenterMessage(const FString& Message, bool bPersistent);
	static void SetShown(UWidget* W, bool bShown);
};
