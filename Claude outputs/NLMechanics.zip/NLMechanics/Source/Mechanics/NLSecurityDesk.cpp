#include "NLSecurityDesk.h"
#include "NLSecurityCamera.h"
#include "NLPowerConsumerComponent.h"
#include "NLPlayerCharacter.h"
#include "Camera/CameraComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/ArrowComponent.h"
#include "Components/AudioComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Kismet/GameplayStatics.h"

ANLSecurityDesk::ANLSecurityDesk()
{
	PrimaryActorTick.bCanEverTick = false;

	Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	RootComponent = Root;

	DeskMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("DeskMesh"));
	DeskMesh->SetupAttachment(Root);

	MonitorMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("MonitorMesh"));
	MonitorMesh->SetupAttachment(Root);

	ViewCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("ViewCamera"));
	ViewCamera->SetupAttachment(Root);
	ViewCamera->SetRelativeLocation(FVector(-80.f, 0.f, 120.f));

	SeatPoint = CreateDefaultSubobject<UArrowComponent>(TEXT("SeatPoint"));
	SeatPoint->SetupAttachment(Root);
	SeatPoint->SetRelativeLocation(FVector(-90.f, 0.f, 90.f));

	MonitorAudio = CreateDefaultSubobject<UAudioComponent>(TEXT("MonitorAudio"));
	MonitorAudio->SetupAttachment(MonitorMesh);
	MonitorAudio->bAutoActivate = false;

	PowerConsumer = CreateDefaultSubobject<UNLPowerConsumerComponent>(TEXT("PowerConsumer"));
}

void ANLSecurityDesk::BeginPlay()
{
	Super::BeginPlay();
	PowerConsumer->OnPowerStateChanged.AddDynamic(this, &ANLSecurityDesk::HandlePowerChanged);

	MonitorMID = MonitorMesh->CreateDynamicMaterialInstance(MonitorMaterialIndex);
	if (MonitorMID && FeedRenderTarget)
	{
		MonitorMID->SetTextureParameterValue(FeedTextureParam, FeedRenderTarget);
	}
	if (MonitorHumLoop)
	{
		MonitorAudio->SetSound(MonitorHumLoop);
	}

	Cameras.RemoveAll([](const TObjectPtr<ANLSecurityCamera>& Cam) { return Cam == nullptr; });
	ActiveIndex = 0;

	// Başlangıç durumunu sessizce uygula
	if (MonitorMID) MonitorMID->SetScalarParameterValue(PowerParam, IsPowered() ? 1.f : 0.f);
	if (IsPowered()) MonitorAudio->Play();
	RefreshFeed();
}

void ANLSecurityDesk::Interact(ANLPlayerCharacter* Player)
{
	if (Player && !bPlayerSeated)
	{
		Player->SitAtDesk(this);
	}
}

FText ANLSecurityDesk::GetInteractPrompt(const ANLPlayerCharacter* Player) const
{
	return bPlayerSeated ? FText::GetEmpty() : FText::FromString(TEXT("[E] Masaya otur"));
}

void ANLSecurityDesk::SwitchToCamera(int32 Index)
{
	if (!IsPowered() || !Cameras.IsValidIndex(Index) || Index == ActiveIndex) return;

	ActiveIndex = Index;
	UGameplayStatics::PlaySound2D(this, CameraSwitchSound);
	RefreshFeed();
	OnActiveCameraChanged.Broadcast(ActiveIndex);
}

void ANLSecurityDesk::NextCamera()
{
	if (Cameras.Num() > 0) SwitchToCamera((ActiveIndex + 1) % Cameras.Num());
}

void ANLSecurityDesk::PreviousCamera()
{
	if (Cameras.Num() > 0) SwitchToCamera((ActiveIndex - 1 + Cameras.Num()) % Cameras.Num());
}

bool ANLSecurityDesk::FlashActiveCamera()
{
	ANLSecurityCamera* Cam = GetActiveCamera();
	return Cam && Cam->Flash();
}

ANLSecurityCamera* ANLSecurityDesk::GetActiveCamera() const
{
	return Cameras.IsValidIndex(ActiveIndex) ? Cameras[ActiveIndex].Get() : nullptr;
}

bool ANLSecurityDesk::IsPowered() const
{
	return PowerConsumer && PowerConsumer->IsPowered();
}

FTransform ANLSecurityDesk::GetSeatTransform() const
{
	return SeatPoint->GetComponentTransform();
}

void ANLSecurityDesk::OnPlayerSeated()
{
	bPlayerSeated = true;
	UGameplayStatics::PlaySoundAtLocation(this, SitDownSound, SeatPoint->GetComponentLocation());
}

void ANLSecurityDesk::OnPlayerLeft()
{
	bPlayerSeated = false;
}

void ANLSecurityDesk::HandlePowerChanged(bool bHasPower)
{
	if (MonitorMID)
	{
		MonitorMID->SetScalarParameterValue(PowerParam, bHasPower ? 1.f : 0.f);
	}

	// Oyunun ilk anlarında (sistemler kayıt olurken) açılış/kapanış sesi çalma
	const bool bPlaySounds = GetWorld()->GetTimeSeconds() > 1.f;

	if (bHasPower)
	{
		if (bPlaySounds) UGameplayStatics::PlaySoundAtLocation(this, ComputerOnSound, MonitorMesh->GetComponentLocation());
		MonitorAudio->Play();
	}
	else
	{
		if (bPlaySounds) UGameplayStatics::PlaySoundAtLocation(this, ComputerOffSound, MonitorMesh->GetComponentLocation());
		MonitorAudio->Stop();
	}

	RefreshFeed();
}

void ANLSecurityDesk::RefreshFeed()
{
	for (int32 i = 0; i < Cameras.Num(); ++i)
	{
		if (Cameras[i])
		{
			Cameras[i]->SetFeedActive(i == ActiveIndex && IsPowered(), FeedRenderTarget);
		}
	}
}
