#include "NLHUDWidget.h"
#include "NLGameMode.h"
#include "NLPlayerCharacter.h"
#include "NLSecurityDesk.h"
#include "NLSecurityCamera.h"
#include "NLGenerator.h"
#include "NLFlashlightComponent.h"
#include "NLPowerSubsystem.h"
#include "Components/TextBlock.h"
#include "Components/ProgressBar.h"
#include "Kismet/GameplayStatics.h"

void UNLHUDWidget::NativeConstruct()
{
	Super::NativeConstruct();

	if (ANLGameMode* GM = GetWorld()->GetAuthGameMode<ANLGameMode>())
	{
		GM->OnDayStarted.AddDynamic(this, &UNLHUDWidget::HandleDayStarted);
		GM->OnDayEnded.AddDynamic(this, &UNLHUDWidget::HandleDayEnded);
		GM->OnShowGameOverScreen.AddDynamic(this, &UNLHUDWidget::HandleGameOverScreen);
		GM->OnGameWon.AddDynamic(this, &UNLHUDWidget::HandleGameWon);
	}

	// Tamir bölgesi soldan ölçeklensin
	if (RepairZone) RepairZone->SetRenderTransformPivot(FVector2D(0.f, 0.5f));

	SetShown(GameOverPanel, false);
	SetShown(RepairPanel, false);
	SetShown(CenterMessageText, false);
}

void UNLHUDWidget::SetShown(UWidget* W, bool bShown)
{
	if (W) W->SetVisibility(bShown ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
}

void UNLHUDWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	const ANLGameMode* GM = GetWorld()->GetAuthGameMode<ANLGameMode>();
	const ANLPlayerCharacter* Player = Cast<ANLPlayerCharacter>(GetOwningPlayerPawn());
	const UNLPowerSubsystem* Power = GetWorld()->GetSubsystem<UNLPowerSubsystem>();
	const ANLGenerator* Generator = Power ? Power->GetGenerator() : nullptr;
	const bool bHasPower = Power && Power->HasPower();

	// --- Gün & saat ---
	if (GM)
	{
		if (DayText) DayText->SetText(FText::FromString(FString::Printf(TEXT("GECE %d / %d"), GM->GetCurrentDay(), GM->GetTotalDays())));
		if (ClockText)
		{
			const float Hours = NightStartHour + (NightEndHour - NightStartHour) * GM->GetDayProgress();
			const int32 H = FMath::FloorToInt(Hours);
			const int32 M = FMath::FloorToInt((Hours - H) * 60.f);
			ClockText->SetText(FText::FromString(FString::Printf(TEXT("%02d:%02d AM"), H == 0 ? 12 : H, M)));
		}
	}

	if (!Player)
	{
		return;
	}

	const ENLPlayerMode Mode = Player->GetMode();

	if (InteractPromptText) InteractPromptText->SetText(Player->GetCurrentInteractPrompt());
	if (FlashlightBar && Player->GetFlashlight()) FlashlightBar->SetPercent(Player->GetFlashlight()->GetBatteryPercent());
	if (FuelCanText)
	{
		SetShown(FuelCanText, Player->HasFuelCan());
		FuelCanText->SetText(FText::FromString(TEXT("Benzin bidonu taşıyorsun")));
	}

	// --- Kamera arayüzü ---
	const bool bSeated = Mode == ENLPlayerMode::Seated;
	SetShown(CameraPanel, bSeated && bHasPower);
	SetShown(NoPowerPanel, bSeated && !bHasPower);

	if (bSeated && bHasPower)
	{
		const ANLSecurityDesk* Desk = Player->GetCurrentDesk();
		const ANLSecurityCamera* Cam = Desk ? Desk->GetActiveCamera() : nullptr;
		if (CameraNameText && Cam) CameraNameText->SetText(Cam->GetCameraName());
		if (FlashCooldownBar && Cam) FlashCooldownBar->SetPercent(1.f - Cam->GetCooldownPercent());
		if (FuelBar && Generator) FuelBar->SetPercent(Generator->GetFuelPercent());
	}

	if (GeneratorStatusText && Generator)
	{
		FString Status;
		if (Generator->IsBroken()) Status = TEXT("JENERATÖR ARIZALI!");
		else if (Generator->GetFuelPercent() <= 0.f) Status = TEXT("BENZİN BİTTİ!");
		else if (Generator->GetFuelPercent() < 0.15f) Status = TEXT("BENZİN AZALIYOR");
		GeneratorStatusText->SetText(FText::FromString(Status));
	}

	// --- Tamir barı ---
	const bool bRepairing = Mode == ENLPlayerMode::Repairing && Player->GetCurrentGenerator();
	SetShown(RepairPanel, bRepairing);
	if (bRepairing)
	{
		const ANLGenerator* Gen = Player->GetCurrentGenerator();
		if (RepairProgressBar) RepairProgressBar->SetPercent(Gen->GetRepairProgress());
		if (RepairNeedle) RepairNeedle->SetRenderTranslation(FVector2D(Gen->GetNeedlePosition() * RepairTrackWidth, 0.f));
		if (RepairZone)
		{
			RepairZone->SetRenderTranslation(FVector2D(Gen->GetZoneStart() * RepairTrackWidth, 0.f));
			// Bölge Image'ının genişliği 1 piksel tasarlanırsa X ölçeği = gerçek genişlik
			RepairZone->SetRenderScale(FVector2D(Gen->GetZoneWidth() * RepairTrackWidth, 1.f));
		}
	}

	// --- Orta mesaj soluklaşması ---
	if (CenterMessageText && !bPersistentMessage && CenterMessageTimer > 0.f)
	{
		CenterMessageTimer -= InDeltaTime;
		const float FadeTime = 1.f;
		CenterMessageText->SetRenderOpacity(FMath::Clamp(CenterMessageTimer / FadeTime, 0.f, 1.f));
		if (CenterMessageTimer <= 0.f) SetShown(CenterMessageText, false);
	}
}

void UNLHUDWidget::ShowCenterMessage(const FString& Message, bool bPersistent)
{
	if (!CenterMessageText) return;
	CenterMessageText->SetText(FText::FromString(Message));
	CenterMessageText->SetRenderOpacity(1.f);
	SetShown(CenterMessageText, true);
	CenterMessageTimer = CenterMessageDuration;
	bPersistentMessage = bPersistent;
}

void UNLHUDWidget::HandleDayStarted(int32 Day)
{
	ShowCenterMessage(FString::Printf(TEXT("DAY %d"), Day), false);
}

void UNLHUDWidget::HandleDayEnded(int32 Day)
{
	ShowCenterMessage(TEXT("06:00 AM"), false);
}

void UNLHUDWidget::HandleGameOverScreen(ENLGameOverReason Reason)
{
	SetShown(GameOverPanel, true);
	ShowCenterMessage(TEXT("GAME OVER"), true);
}

void UNLHUDWidget::HandleGameWon()
{
	ShowCenterMessage(TEXT("FENER SÖNMEDİ.\n7 GECE TAMAMLANDI"), true);
}
